<?php
$host = 'localhost'; 
$dbname = 'zsourcecodehomes_data'; // Thay bằng tên cơ sở dữ liệu của bạn
$username = 'zsourcecodehomes_data'; // Tên người dùng MySQL
$password = 'zsourcecodehomes_data'; // Mật khẩu MySQL

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
## CONFIG DATA
$access_token = ""; // lấy token tại momosv3.apimienphi.com
$sodienthoai  = "113"; // số điện thoại nhận tiền và trả thưởng ( Đã cài token nào sài chung từ tài khoản đó)
$tilecltx  = "3";
$tilecltx2  = "1.92";
$tile1p3 = "3";
$min = "100";
$max = "500099";
$linkadmin = "";
$linkbox = "";
$id_tele = "";
$token_tele = "";
## END

## ĐUÔI GAME CHƠI BẰNG SỐ CUỐI SỐ TIỀN
$chan = "21";
$le = "22";
$tai = "24";
$xiu = "23";
$chan2 = "16";
$le2 = "17";
$xiu2 = "18";
$tai2 = "19";
$N0 = "60";
$N1 = "61";
$N2 = "62";
$N3 = "63";
?>
