<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/config/index.php';

// Kiểm tra xem mã giao dịch có được gửi qua không
if (isset($_POST['tran_id'])) {
    $tran_id = $conn->real_escape_string($_POST['tran_id']);

    // Truy vấn kiểm tra mã giao dịch
    $query = "SELECT * FROM transactions WHERE magiaodich = '$tran_id'";
    $result = $conn->query($query);

    if ($result === false) {
        echo "Lỗi khi truy vấn cơ sở dữ liệu: " . $conn->error;
    } else {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $ketqua2 = $row['ketqua'] - $row['magiaodich'];
            $ketquaCuoi = substr($ketqua2, -4);

            echo "<p><strong>Mã Giao Dịch:</strong> " . $row['magiaodich'] . "</p>";
                 echo "<p><strong>Mã Dự Bị (Nếu Lỗi):</strong> " . $row['mard'] . "</p>";
                 echo "<p><strong>Mã Mili :</strong> " . $ketquaCuoi . "</p>";
            echo "<p><strong>Số Điện Thoại:</strong> " . $row['nguoichuyen'] . "</p>";
            echo "<p><strong>Tổng MGD:</strong> " . $row['ketqua'] . " = " . $row['magiaodich'] . " + ". $ketquaCuoi."</p>";
            echo "<p><strong>Tiền Đặt:</strong> " . number_format($row['sotien'], 0, ',', '.') . "</p>";
            echo "<p><strong>Nội Dung:</strong> " . $row['noidung'] . "</p>";
            
            // Hiển thị tình trạng giao dịch
            switch ($row['tinhtrang']) {
                case 'chienthang':
                    echo "<p><strong>Tình Trạng:</strong> Chiến Thắng</p>";
                    break;
                case 'thua':
                    echo "<p><strong>Tình Trạng:</strong> Thua</p>";
                    break;
                       case 'saiminmax':
                    echo "<p><strong>Tình Trạng:</strong> Sai Min Max , vui lòng liên hệ ADMIN</p>";
                    break;
                case 'khongxacdinh':
                    echo "<p><strong>Tình Trạng:</strong> Sai Nội Dung & IB Ad Hoàn 50%</p>";
                    break;
                default:
                    echo "<p><strong>Tình Trạng:</strong> Không Xác Định</p>";
                    break;
            }

            // Hiển thị trạng thái trả thưởng
            echo "<p><strong>Trả Thưởng:</strong> " . ($row['da_gui'] == 1 ? 'Đã Trả Thưởng' : 'Chờ Trả Thưởng') . "</p>";
        } else {
            echo "<p>Không tìm thấy giao dịch với mã này.</p>";
        }
    }
} else {
    echo "<p>Mã giao dịch không được cung cấp.</p>";
}

$conn->close();
?>
