<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) . '/config/index.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $phoneto = $_POST['phoneto'];
    $amount = $_POST['amount'];
    $note = $_POST['note'];

$dataPost = array(
    "access_token" => $access_token,
    "phone" => $sodienthoai,
    "phoneto" => $phoneto,
    "amount" => $amount,
    "note" => $note
);

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => "https://momosv3.apimienphi.com/api/sendMoneyMomo",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode($dataPost),
    CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        "accept: application/json",
    ),
));

$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE); 
curl_close($curl);

$result = json_decode($response, true);
if ($http_code == 200 && isset($result['error']) && $result['error'] == 0) {
    $stmt = $conn->prepare("INSERT INTO chuyentien_thucong (phoneto, amount, note) VALUES (?, ?, ?)");
    $stmt->bind_param("sis", $phoneto, $amount, $note);
    $stmt->execute();
    $stmt->close();
    $message = "Chuyển tiền thành công!";
} else {
    $error_message = $result['message'] ?? 'Không xác định';
    $message = "Chuyển tiền thất bại ( vui lòng thử lại )! Mã lỗi: " . $http_code . " - Thông báo lỗi: " . $error_message;
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chuyển Tiền Thủ Công</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <h2>Chuyển Tiền Thủ Công</h2>

        <?php if (isset($message)): ?>
            <div class="alert alert-info"><?= $message ?></div>
        <?php endif; ?>

        <form method="POST" class="mb-5">
            
            <div class="mb-3">
                <label for="phoneto" class="form-label">Số điện thoại người nhận</label>
                <input type="text" class="form-control" id="phoneto" name="phoneto" required>
            </div>
            <div class="mb-3">
                <label for="amount" class="form-label">Số tiền</label>
                <input type="number" class="form-control" id="amount" name="amount" required>
            </div>
            <div class="mb-3">
                <label for="note" class="form-label">Nội Dung</label>
                <input type="text" class="form-control" id="note" name="note">
            </div>
            <button type="submit" class="btn btn-primary">Chuyển tiền</button>
        </form>

        <h2>Lịch Sử Giao Dịch</h2>

        <?php
        // Phân trang
        $limit = 7;
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $offset = ($page - 1) * $limit;

        $result = $conn->query("SELECT * FROM chuyentien_thucong ORDER BY thoigian DESC LIMIT $limit OFFSET $offset");
        $total = $conn->query("SELECT COUNT(*) AS total FROM chuyentien_thucong")->fetch_assoc()['total'];
        $total_pages = ceil($total / $limit);

        if ($result->num_rows > 0): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Số người nhận</th>
                        <th>Số tiền</th>
                        <th>Nội Dung</th>
                        <th>Thời gian</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= $row['phoneto'] ?></td>
<td><?= number_format($row['amount'], 0, ',', '.') ?> VND</td>
                            <td><?= $row['note'] ?></td>
                            <td><?= $row['thoigian'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <!-- Phân trang -->
            <nav aria-label="Page navigation">
                <ul class="pagination">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php else: ?>
            <div class="alert alert-warning">Không có giao dịch nào.</div>
        <?php endif; ?>
    </div>
</body>
</html>
