<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) . '/config/index.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($conn) || !$conn instanceof mysqli) {
    die("Kết nối MySQL không hợp lệ.");
}

// Giả sử rằng $access_token và $sodienthoai đã được định nghĩa trước đó
$dataPost = array(
    "access_token" => $access_token,
    "phone" => $sodienthoai,
    "limit" => 10,
    "offset" => 0 
);

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => "https://momosv3.apimienphi.com/api/getTransHistory",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode($dataPost),
    CURLOPT_HTTPHEADER => array(
        "Content-Type: application/json",
        "accept: application/json",
        "cache-control: no-cache"
    ),
));

$response = curl_exec($curl);
if ($response === false) {
    die('CURL Error: ' . curl_error($curl));
}
curl_close($curl);

$data = json_decode($response, true);

if (isset($data['data']) && is_array($data['data'])) {
    $stmt = $conn->prepare("INSERT INTO transactions (nguoichuyen, tennguoichuyen, magiaodich, mard, ketqua, sotien, noidung, tinhtrang, thoigian) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if ($stmt === false) {
        die("Lỗi khi chuẩn bị câu lệnh SQL: " . $conn->error);
    }

    foreach ($data['data'] as $transaction) {
        $nguoichuyen = $transaction['partnerId'] ?? '';
        $tennguoichuyen = $transaction['partnerName'] ?? '';
        $magiaodich = $transaction['tranId'] ?? '';
        
        $sotien = floatval($transaction['amount'] ?? 0); 
        $noidung = $transaction['comment'] ?? '';
        $thoigian = $transaction['create_time'] ?? '';

        // Kiểm tra nếu magiaodich đã tồn tại trong cơ sở dữ liệu
        $checkStmt = $conn->prepare("SELECT COUNT(*) FROM transactions WHERE magiaodich = ?");
        if ($checkStmt === false) {
            die("Lỗi khi chuẩn bị câu lệnh kiểm tra SQL: " . $conn->error);
        }
        $checkStmt->bind_param("s", $magiaodich);
        $checkStmt->execute();
        $checkStmt->bind_result($count);
        $checkStmt->fetch();
        $checkStmt->close();

        if ($count > 0) {
            echo "Giao dịch với magiaodich $magiaodich đã tồn tại.<br>";
            continue; // Bỏ qua giao dịch này
        }

        // Tạo số ngẫu nhiên cho mard
        $mard = str_pad(random_int(0, 9999), 4, '0', STR_PAD_LEFT); // số ngẫu nhiên từ 0000 đến 9999
        $duoi_so_tien = substr($sotien, -2); //ẩn tất cả chỉ hiện 2 số cuối
        // Tính ketqua
        if ($sotien > 1020) {
            // Nếu số tiền lớn hơn 1002 VND, thêm số cuối vào ketqua
            $hiddenIndex = random_int(0, strlen($magiaodich) - 1); // Chọn chỉ mục ngẫu nhiên để ẩn
            $hiddenDigit = $magiaodich[$hiddenIndex]; // Lưu số để thay thế
            $magiaodichHidden = substr_replace($magiaodich, '', $hiddenIndex, 1); // Thay thế số được ẩn bằng '*'
            $randomDigits = str_pad(random_int(0, 99999), 1, '', STR_PAD_LEFT); // Tạo 1 số ngẫu nhiên
            $ketqua = $magiaodichHidden + $randomDigits; // Ghép kết quả lại

            switch (strtolower($duoi_so_tien)) {
                case $chan:
                case $chan2:
                    $randomDigit = [1, 3, 5, 7, 9][array_rand([1, 3, 5, 7, 9])];
                    $ketqua .= $randomDigit;  // Thêm số cuối vào ketqua
                    break;
                case $le:
                case $le2:
                    $randomDigit = [2, 4, 6, 8, 0][array_rand([2, 4, 6, 8, 0])];
                    $ketqua .= $randomDigit;  // Thêm số cuối vào ketqua
                    break;
                case $tai:
                case $tai2:
                    $randomDigit = [0, 1, 2, 3, 4][array_rand([0, 1, 2, 3, 4])];
                    $ketqua .= $randomDigit;  // Thêm số cuối vào ketqua
                    break;
                case $xiu:
                case $xiu2:
                    $randomDigit = [5, 6, 7, 8, 9][array_rand([5, 6, 7, 8, 9])];
                    $ketqua .= $randomDigit;  // Thêm số cuối vào ketqua
                    break;
                    //1 Phần 3
                    case $N2:
                case $N3:
                    $randomDigit = [0, 4, 5, 6, 7, 8, 9][array_rand([0, 4, 5, 6, 7, 8, 9])];
                    $ketqua .= $randomDigit;  // Thêm số cuối vào ketqua
                    break;
                    case $N1:
                case $N3:
                    $randomDigit = [0, 1, 2, 3, 7, 8, 9][array_rand([0, 1, 2, 3, 7, 8, 9])];
                    $ketqua .= $randomDigit;  // Thêm số cuối vào ketqua
                    break;
                    case $N1:
                case $N2:
                    $randomDigit = [0, 1, 2, 3, 4, 5, 6][array_rand([0, 1, 2, 3, 4, 5, 6])];
                    $ketqua .= $randomDigit;  // Thêm số cuối vào ketqua
                    break;
                    case $N1:
                case $N2:
                case $N3:
                    $randomDigit = [1, 2, 3, 4, 5, 6, 7, 8, 9][array_rand([1, 2, 3, 4, 5, 6, 7, 8, 9])];
                    $ketqua .= $randomDigit;  // Thêm số cuối vào ketqua
                    break;
                default:
                    $tinhtrang = 'khongxacdinh'; // Nếu không xác định được noidung
            }
        } else {
            // Nếu số tiền nhỏ hơn hoặc bằng 1002 VND
            $ketqua = $magiaodich + $mard;
        }

        // Xác định soCuoi dựa trên ketqua
        $soCuoi = substr($ketqua, -1);

        // Xác định tinhtrang dựa trên noidung và soCuoi
        switch (strtolower($duoi_so_tien)) {
            case $chan:
                $tinhtrang = in_array($soCuoi, [2, 4, 6, 8]) ? 'chienthang' : 'thua';
                break;
            case $le:
                $tinhtrang = in_array($soCuoi, [1, 3, 5, 7]) ? 'chienthang' : 'thua';
                break;
            case $tai:
                $tinhtrang = in_array($soCuoi, [5, 6, 7, 8]) ? 'chienthang' : 'thua';
                break;
            case $xiu:
                $tinhtrang = in_array($soCuoi, [1, 2, 3, 4]) ? 'chienthang' : 'thua';
                break;
            case $chan2:
                $tinhtrang = in_array($soCuoi, [0, 2, 4, 6, 8]) ? 'chienthang' : 'thua';
                break;
            case $le2:
                $tinhtrang = in_array($soCuoi, [1, 3, 5, 7, 9]) ? 'chienthang' : 'thua';
                break;
            case $tai2:
                $tinhtrang = in_array($soCuoi, [5, 6, 7, 8, 9]) ? 'chienthang' : 'thua';
                break;
            case $xiu2:
                $tinhtrang = in_array($soCuoi, [0, 1, 2, 3, 4]) ? 'chienthang' : 'thua';
                break;
                case $N0:
                $tinhtrang = in_array($soCuoi, [0]) ? 'chienthang' : 'thua';
                break;
                case $N1:
                $tinhtrang = in_array($soCuoi, [1, 2, 3]) ? 'chienthang' : 'thua';
                break;
                case $N2:
                $tinhtrang = in_array($soCuoi, [4, 5, 6]) ? 'chienthang' : 'thua';
                break;
                case $N3:
                $tinhtrang = in_array($soCuoi, [7, 8, 9]) ? 'chienthang' : 'thua';
                break;
            default:
                $tinhtrang = 'khongxacdinh'; // Nếu không xác định được noidung
        }

        $stmt->bind_param("sssssssss", $nguoichuyen, $tennguoichuyen, $magiaodich, $mard, $ketqua, $sotien, $noidung, $tinhtrang, $thoigian);
        if (!$stmt->execute()) {
            echo "Lỗi khi thực thi câu lệnh: " . $stmt->error . "<br>";
        }
    }
    $stmt->close();
}

$conn->close();
?>