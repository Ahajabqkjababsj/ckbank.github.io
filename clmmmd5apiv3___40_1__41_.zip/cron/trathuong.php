<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) . '/config/index.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Kiểm tra kết nối cơ sở dữ liệu
if (!isset($conn) || !$conn instanceof mysqli) {
    die("Kết nối MySQL không hợp lệ.");
}

// Truy vấn các giao dịch có trạng thái 'chienthang' mà chưa gửi tiền và da_gui = 0
$query = "SELECT id, nguoichuyen, sotien, magiaodich, noidung FROM transactions WHERE tinhtrang = 'chienthang' AND trathuong IS NULL AND da_gui = 0 LIMIT 1";
$result = $conn->query($query);

 $names = ["📦 Trả tiền hàng", "🍛 Tiền ăn uống", "🎦 Tiền xem phim", "💸 Tiền cho gia đình", "🛒 Tiền chợ/siêu thị", "Mua Hàng Online", "Săn Hàng Shopper", "Nạp Thẻ Cào"];
 $randomName = $names[array_rand($names)];
if ($result === false) {
    die("Lỗi khi truy vấn cơ sở dữ liệu: " . $conn->error);
}

if ($transaction = $result->fetch_assoc()) {
    $id = intval($transaction['id']); // Chuyển đổi sang kiểu số nguyên
    $nguoichuyen = $conn->real_escape_string($transaction['nguoichuyen']);
    $sotien = floatval($transaction['sotien']); // Chuyển đổi sang kiểu số thực
    $magiaodich = $conn->real_escape_string($transaction['magiaodich']);
    $noidung = strtolower(trim($conn->real_escape_string($transaction['noidung']))); // Bảo vệ nội dung

    // Lấy 2 số cuối của số tiền
    $lastTwoDigits = substr($sotien, -2);

    // Xác định tỷ lệ trả thưởng dựa trên 2 số cuối
    if (in_array($lastTwoDigits, [$chan, $le, $xiu, $tai])) {
        $tile = $tilecltx; // Cần đảm bảo biến này đã được khởi tạo
    } elseif (in_array($lastTwoDigits, [$chan2, $le2, $xiu2, $tai2])) {
        $tile = $tilecltx2; // Cần đảm bảo biến này đã được khởi tạo
    } elseif (in_array($lastTwoDigits, [$N0, $N1, $N2, $N3])) {
        $tile = $tile1p3; // Cần đảm bảo biến này đã được khởi tạo
    } else {
        echo "Nội dung không hợp lệ cho giao dịch $id. Bỏ qua giao dịch này.<br>";
        $conn->close();
        exit;
    }

    // Tính toán số tiền trả thưởng
    $sotien_tra_thuong = $sotien * $tile;

    // Tạo dữ liệu POST cho API
    $data = array(
        'access_token' => $access_token,
        'phone' => $sodienthoai, // Thay thế bằng số điện thoại tài khoản Momo của bạn
        'phoneto' => $nguoichuyen,
        'amount' => $sotien_tra_thuong,
        'note' => $randomName
    );

    // Gửi yêu cầu API qua cURL
    $ch = curl_init('https://momosv3.apimienphi.com/api/sendMoneyMomo');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length: ' . strlen(json_encode($data))
    ));

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Lỗi: ' . curl_error($ch) . "<br>";
    } else {
        $responseData = json_decode($response, true);

        // Kiểm tra nếu API thành công
        if (isset($responseData['error']) && $responseData['error'] == 0) {
            $stmt = $conn->prepare("UPDATE transactions SET trathuong = 'done', da_gui = 1 WHERE id = ?");
            if ($stmt === false) {
                die("Lỗi khi chuẩn bị câu lệnh SQL: " . $conn->error);
            }
            $stmt->bind_param('i', $id);
            if ($stmt->execute()) {
                echo "Đã trả thưởng thành công cho giao dịch $id với số tiền $sotien_tra_thuong.<br>";
            } else {
                echo "Lỗi khi cập nhật giao dịch $id.<br>";
            }
            $stmt->close();
        } else {
            // Xử lý trường hợp API không thành công
            echo "API không thành công cho giao dịch $id. Phản hồi API: " . print_r($responseData, true) . "<br>";
        }
    }

    curl_close($ch);

    // Thêm độ trễ giữa mỗi lần gọi API
    sleep(1); // Chờ 1 giây trước khi xử lý giao dịch tiếp theo
} else {
    echo "Không có giao dịch nào cần xử lý.<br>";
}

$conn->close();
?>
