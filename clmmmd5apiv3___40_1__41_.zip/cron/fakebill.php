<?php
// Kết nối đến cơ sở dữ liệu
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) . '/config/index.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($conn) || !$conn instanceof mysqli) {
    die("Kết nối MySQL không hợp lệ.");
}

// Đặt múi giờ thành Việt Nam
date_default_timezone_set('Asia/Ho_Chi_Minh');

// Hàm tạo mã ngẫu nhiên
function generateRandomString($length = 10) {
    return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
}

// Tạo dữ liệu giả
$prefixes = ['09', '03', '07', '05'];
$nguoichuyen = $prefixes[array_rand($prefixes)] . rand(10000000, 99999999);
$tennguoichuyen = "Người dùng " . generateRandomString(5);
$magiaodich = generateRandomString(10);
$mard = generateRandomString(4);
$ketqua = $magiaodich . $mard;
$values2 = ["50".$chan, "700".$le, "3000".$chan2, "9907", "10004", "15007", "17008", "19003", "20008", "23006", "28001", "40006", "30007", "45004", "50006", "30005", "70002", "90001", "85006", "100005", "13003", "10001", "15001", "19003", "30007", "20003", "88008"];

$sotien = $values2[array_rand($values2)];
$values = ["", "", "", "", "", "", "", ""];
$noidung = $values[array_rand($values)];
$tinhtrang = "chienthang";
$thoigian = date('Y-m-d H:i:s');
$da_gui = 1; // Đặt giá trị 1 (số) thay vì chuỗi
$trathuong = $sotien * 2.4;

// Thực hiện câu lệnh SQL để thêm bản ghi
$sql = "INSERT INTO fakebill (nguoichuyen, tennguoichuyen, magiaodich, mard, ketqua, sotien, noidung, tinhtrang, thoigian, da_gui, trathuong) 
        VALUES ('$nguoichuyen', '$tennguoichuyen', '$magiaodich', '$mard', '$ketqua', $sotien, '$noidung', '$tinhtrang', '$thoigian', $da_gui, $trathuong)";

if ($conn->query($sql) === TRUE) {
    //$content = "<b>💵 [Win] - Xin chúc mừng người chơi ". substr($nguoichuyen, 0, 5) . "**** vừa thắng " . number_format($sotien, 0, ',', '.') . " VNĐ. Chúc bạn tiếp tục may mắn và thắng lớn</b>
    //<b></b>
    //<b>😒<a href='https://" . $_SERVER['SERVER_NAME'] . "/'>" . $_SERVER['SERVER_NAME'] . "</a> - Mỗi Ngày Lụm 100 Triệu Người Ae</b>";

    //$apiToken = $token_tele;

    //$data = [
     //   'chat_id' => $id_tele,
      //  'text' => $content,
      //  'parse_mode' => 'HTML'
    //];

    //$response = file_get_contents("https://api.telegram.org/bot{$apiToken}/sendMessage?" . http_build_query($data));
    
    echo "Bản ghi mới đã được thêm thành công!";
} else {
    echo "Lỗi: " . $sql . "<br>" . $conn->error;
}

// Đóng kết nối
$conn->close();
?>
