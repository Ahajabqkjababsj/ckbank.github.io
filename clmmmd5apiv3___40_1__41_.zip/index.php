<!DOCTYPE html>
<html lang="vi" data-bs-theme="dark">
<head>
<meta charset="utf-8">
<title>Chẳn Lẻ Momo Tự Động - Minh Bạch - Thuật Toán Random Công Bằng 24/7 </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="https://i.imgur.com/f24cV7Z.png" type="image/x-icon">
<meta name="description" content="Trả thưởng 5s Cực Nhanh Chóng, Hoàn toàn tự động">
<meta name="keywords" content="clmm, cl momo, clmomo, cltx, clmm, chẳn lẻ momo, chẳn lẻ momo, momo, momo, chẳn lẻ tài xỉu, chẳn lẻ momo, chẳn lẻ tài xỉu, clmm momo, cl momo, clmm momo, momo cl, cl mo mo, momo chẵn lẻ 1k, clmm, cl momo 1k, momo chẵn lẻ">
<meta property="og:title" content="Chẳn Lẻ Momo Tự Động - Minh Bạch - Thuật Toán Random Công Bằng 24/7">
<meta property="og:type" content="website">
<meta property="og:url" content="//">
<meta property="og:description" content="Chẳn Lẻ Momo Tự Động - Minh Bạch - Thuật Toán Random Công Bằng 24/7">
<meta property="og:site_name" content="Chẳn Lẻ Momo Tự Động - Minh Bạch - Thuật Toán Random Công Bằng 24/7">
<meta property="article:section" content="Chẳn Lẻ Momo Tự Động - Minh Bạch - Thuật Toán Random Công Bằng 24/7">
<meta property="article:tag" content="Chẳn Lẻ Momo Tự Động - Minh Bạch - Thuật Toán Random Công Bằng 24/7">
<meta property="og:image" content="https://i.imgur.com/f24cV7Z.png">
<meta name="twitter:card" content="https://i.imgur.com/f24cV7Z.png">
<meta name="twitter:image:src" content="https://i.imgur.com/f24cV7Z.png">
<link rel="icon" href="https://i.imgur.com/f24cV7Z.png">
<link rel="apple-touch-icon" href="https://i.imgur.com/f24cV7Z.png">
<meta name="twitter:description" content="Chẳn Lẻ Momo Tự Động - Minh Bạch - Thuật Toán Random Công Bằng 24/7">

<link href="/assets/css/vendor.min.css" rel="stylesheet">
<link href="/assets/css/app.min.css" rel="stylesheet">
<link href="/assets/plugins/jvectormap-next/jquery-jvectormap.css" rel="stylesheet">


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.14/sweetalert2.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.14/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/clipboard@2.0.10/dist/clipboard.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/>
<link rel="stylesheet" href="//cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">
<script src="//cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="/assets/css/style.css?1728688126"/>
<link href="/assets/plugins/summernote/dist/summernote-lite.css?1728688126" rel="stylesheet">
<script src="/assets/plugins/summernote/dist/summernote-lite.min.js?1728688126"></script>

<script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body><div id="app" class="app app-sidebar-collapsed">
<div id="header" class="app-header">
<div class="desktop-toggler">
<button type="button" class="menu-toggler" data-toggle-class="app-sidebar-collapsed" data-dismiss-class="app-sidebar-toggled" data-toggle-target=".app">
<span class="bar"></span>
<span class="bar"></span>
<span class="bar"></span>
</button>
</div>

<div class="mobile-toggler">
<button type="button" class="menu-toggler" data-toggle-class="app-sidebar-mobile-toggled" data-toggle-target=".app">
<span class="bar"></span>
<span class="bar"></span>
<span class="bar"></span>
</button>
<img src="https://i.imgur.com/f24cV7Z.png" class="brand-img-text" style="width: 40px">
</div>


<div class="brand">
<a href="/" class="brand-logo">
<!--<span class="brand-img">-->
<!--<span class="brand-img-text text-theme">M</span>-->
<!--</span>-->
<!--<span class="brand-text">MESS.VIN</span>-->
<img src="https://i.imgur.com/f24cV7Z.png" class="brand-img-text" style="width: 40px">
</a>
</div>


<div class="menu">
<!-- BẢN QUYỀN THUỘC VỀ RUMHTM -->
</div>
</div>


<div id="sidebar" class="app-sidebar">
<div class="app-sidebar-content" data-scrollbar="true" data-height="100%">
<div class="menu">
<div class="menu-header">MENU</div>
<div class="menu-item active">
<a href="/" class="menu-link">
<span class="menu-icon"><i class="fas fa-home"></i></span>
<span class="menu-text">Cách Chơi</span>
</a>
</div>

</div>
</div>
</div>
<button class="app-sidebar-mobile-backdrop" data-toggle-target=".app" data-toggle-class="app-sidebar-mobile-toggled"></button>

<div id="content" class="app-content"><div class="container">
<div class="row">
<div class="col-xl-12 col-lg-12 mb-3">
<ul class="nav nav-tabs nav-tabs-v2 px-4" role="tablist">
<li class="nav-item me-3" role="presentation"><a href="#cltx" class="nav-link px-2 active" data-bs-toggle="tab" aria-selected="true" role="tab" tabindex="-1" onclick="viewInfoGame('cltx')">CLTX</a></li>
<li class="nav-item me-3" role="presentation"><a href="#cltx2" class="nav-link px-2 " data-bs-toggle="tab" aria-selected="true" role="tab" tabindex="-1" onclick="viewInfoGame('cltx2')">CLTX+2</a></li>
<li class="nav-item me-3" role="presentation"><a href="#1phan3" class="nav-link px-2 " data-bs-toggle="tab" aria-selected="true" role="tab" tabindex="-1" onclick="viewInfoGame('1phan3')">1 Phần 3</a></li>

</ul>
</div>
                    <?php include 'zicking/thongtin.php'; ?>
                    
                </div>
                <div class = "container"> 
                    <div id="trans"></div>
                    <div id="status"></div> 
                    <div class="row">
                        
                        </div>
                        
                    </div>
                </div>
                   <div class="card-arrow">
<div class="card-arrow-top-left"></div>
<div class="card-arrow-top-right"></div>
<div class="card-arrow-bottom-left"></div>
<div class="card-arrow-bottom-right"></div>
</div>

</div>
</div>

<style>
    #timeView {
        display: none;
    }
</style>
<div class="card-arrow">
<div class="card-arrow-top-left"></div>
<div class="card-arrow-top-right"></div>
<div class="card-arrow-bottom-left"></div>
<div class="card-arrow-bottom-right"></div>
</div>

</div>
</div>
</div>
</div>
    
</div>


<div class="app-theme-panel">
<div class="app-theme-panel-container">
<a href="javascript:;" data-toggle="theme-panel-expand" class="app-theme-toggle-btn"><i class="bi bi-sliders"></i></a>
<div class="app-theme-panel-content">
<div class="small fw-bold text-inverse mb-1">Chỉnh Sửa Giao Diện</div>
<div class="card mb-3">

<div class="card-body p-2">
<div class="row gx-2">
<div class="col-6">
<a href="javascript:;" data-toggle="theme-mode-selector" data-theme-mode="dark" class="app-theme-mode-link active">
<div class="img"><img src="/assets/img/mode/dark.jpg" class="object-fit-cover" height="76" width="76" alt="Dark Mode"></div>
<div class="text">Tối</div>
</a>
</div>
<div class="col-6">
<a href="javascript:;" data-toggle="theme-mode-selector" data-theme-mode="light" class="app-theme-mode-link">
<div class="img"><img src="/assets/img/mode/light.jpg" class="object-fit-cover" height="76" width="76" alt="Light Mode"></div>
<div class="text">Sáng</div>
</a>
</div>
</div>
</div>


<div class="card-arrow">
<div class="card-arrow-top-left"></div>
<div class="card-arrow-top-right"></div>
<div class="card-arrow-bottom-left"></div>
<div class="card-arrow-bottom-right"></div>
</div>

</div>
<div class="small fw-bold text-inverse mb-1">Màu Giao Diện</div>
<div class="card mb-3">

<div class="card-body p-2">

<div class="app-theme-list">
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-pink" data-theme-class="theme-pink" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Pink">&nbsp;</a></div>
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-red" data-theme-class="theme-red" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Red">&nbsp;</a></div>
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-warning" data-theme-class="theme-warning" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Orange">&nbsp;</a></div>
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-yellow" data-theme-class="theme-yellow" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Yellow">&nbsp;</a></div>
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-lime" data-theme-class="theme-lime" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Lime">&nbsp;</a></div>
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-green" data-theme-class="theme-green" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Green">&nbsp;</a></div>
<div class="app-theme-list-item active"><a href="javascript:;" class="app-theme-list-link bg-teal" data-theme-class data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Default">&nbsp;</a></div>
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-info" data-theme-class="theme-info" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cyan">&nbsp;</a></div>
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-primary" data-theme-class="theme-primary" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Blue">&nbsp;</a></div>
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-purple" data-theme-class="theme-purple" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Purple">&nbsp;</a></div>
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-indigo" data-theme-class="theme-indigo" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Indigo">&nbsp;</a></div>
<div class="app-theme-list-item"><a href="javascript:;" class="app-theme-list-link bg-gray-100" data-theme-class="theme-gray-200" data-toggle="theme-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Gray">&nbsp;</a></div>
</div>

</div>


<div class="card-arrow">
<div class="card-arrow-top-left"></div>
<div class="card-arrow-top-right"></div>
<div class="card-arrow-bottom-left"></div>
<div class="card-arrow-bottom-right"></div>
</div>

</div>
<div class="small fw-bold text-inverse mb-1">Hình Nền Website</div>
<div class="card">
<div class="app-theme-cover">
<div class="app-theme-cover-item active">
<a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/assets/img/cover/cover-thumb-1.jpg);" data-theme-cover-class data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Default">&nbsp;</a>
</div>
<div class="app-theme-cover-item">
<a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/assets/img/cover/cover-thumb-2.jpg);" data-theme-cover-class="bg-cover-2" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 2">&nbsp;</a>
</div>
<div class="app-theme-cover-item">
<a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/assets/img/cover/cover-thumb-3.jpg);" data-theme-cover-class="bg-cover-3" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 3">&nbsp;</a>
</div>
<div class="app-theme-cover-item">
<a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/assets/img/cover/cover-thumb-4.jpg);" data-theme-cover-class="bg-cover-4" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 4">&nbsp;</a>
</div>
<div class="app-theme-cover-item">
<a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/assets/img/cover/cover-thumb-5.jpg);" data-theme-cover-class="bg-cover-5" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 5">&nbsp;</a>
</div>
<div class="app-theme-cover-item">
<a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/assets/img/cover/cover-thumb-6.jpg);" data-theme-cover-class="bg-cover-6" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 6">&nbsp;</a>
</div>
<div class="app-theme-cover-item">
<a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/assets/img/cover/cover-thumb-7.jpg);" data-theme-cover-class="bg-cover-7" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 7">&nbsp;</a>
</div>
<div class="app-theme-cover-item">
<a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/assets/img/cover/cover-thumb-8.jpg);" data-theme-cover-class="bg-cover-8" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 8">&nbsp;</a>
</div>
<div class="app-theme-cover-item">
<a href="javascript:;" class="app-theme-cover-link" style="background-image: url(/
assets/img/cover/cover-thumb-9.jpg);" data-theme-cover-class="bg-cover-9" data-toggle="theme-cover-selector" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-container="body" data-bs-title="Cover 9">&nbsp;</a>
</div>
</div>
</div>
<div class="card-arrow">
<div class="card-arrow-top-left"></div>
<div class="card-arrow-top-right"></div>
<div class="card-arrow-bottom-left"></div>
<div class="card-arrow-bottom-right"></div>
</div>
</div>
</div>
</div>
</div>

</div>
<div class="foooter">
    <div>Copyright © <?=date('Y');?> <a href="" target="_blank">Admin</a></div>
</div>
<script>
let table = new DataTable('#myTable');
    
function copy(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  Swal.fire("Thành Công", "Copy Thành Công", "success");
  $temp.remove();
}
</script>
<style>
    .foooter {
        text-align: center;
        margin: 10px;
        padding: 10px;
    }
</style>
    
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script src="/assets/js/vendor.min.js" type="f4685338a5db6e2e6873d5ad-text/javascript"></script>
<script src="/assets/js/app.min.js" type="f4685338a5db6e2e6873d5ad-text/javascript"></script>


<script src="/assets/plugins/jvectormap-next/jquery-jvectormap.min.js" type="f4685338a5db6e2e6873d5ad-text/javascript"></script>
<script src="/assets/plugins/jvectormap-content/world-mill.js" type="f4685338a5db6e2e6873d5ad-text/javascript"></script>
<script src="/assets/plugins/apexcharts/dist/apexcharts.min.js" type="f4685338a5db6e2e6873d5ad-text/javascript"></script>
<script src="/assets/js/demo/dashboard.demo.js" type="f4685338a5db6e2e6873d5ad-text/javascript"></script>
<script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="f4685338a5db6e2e6873d5ad-|49" defer></script>
<script defer src="/beacon.min.js/v84a3a4012de94ce1a686ba8c167c359c1696973893317" integrity="sha512-euoFGowhlaLqXsPWQ48qSkBSCFs3DPRyiwVu3FjR96cMPx+Fr+gpWRhIafcHwqwCqWS42RZhIudOvEI+Ckf6MA==" data-cf-beacon='{"rayId":"822ceea6cbea4918","r":1,"version":"2023.10.0","token":"4db8c6ef997743fda032d4f73cfeff63"}' crossorigin="anonymous"></script>
<div id="status"></div> 
    <script>
    function viewInfoGame(code) {
        var TitleGame;
        var DesGame;
                if(code == 'cltx') {
            TitleGame = "CLTX";
            DesGame = "1 số cuối mã giao dịch";
        }
                if(code == 'cltx2') {
            TitleGame = "CLTX+2";
            DesGame = "1 số cuối mã giao dịch";
        }
                if(code == 'gap3') {
            TitleGame = "Gấp 3";
            DesGame = "2 - 3 số cuối mã giao dịch";
        }
                if(code == 'tong3so') {
            TitleGame = "Tổng 3 Số";
            DesGame = "Tổng 3 số cuối mã giao dịch";
        }
                if(code == '1phan3') {
            TitleGame = "1 Phần 3";
            DesGame = "1 số cuối mã giao dịch";
        }
                if(code == 'xien2') {
            TitleGame = "Xiên";
            DesGame = "1 số cuối mã giao dịch";
        }
                if(code == 'doanso') {
            TitleGame = "Đoán Số";
            DesGame = "1 số cuối mã giao dịch";
        }
                if(code == 'lo') {
            TitleGame = "Lô";
            DesGame = "2 số cuối mã giao dịch";
        }
                $("#viewTitleGame").html(TitleGame);
        $("#viewTitleGame2").html(TitleGame);
        $("#viewDesGame").html(DesGame);
    }
    
    
        $(document).ready(function() {
            $('#note').modal('show');
        });
        $("#trans").load("zicking/trans.php"); 
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip()
             setInterval(function () {
            $("#trans").load("zicking/trans.php"); 
            }, 3000);
        });
       
    </script>
    
    
<script>
function dongthongbao() {
             var audio = document.getElementById("myAudio");
             audio.play();
            document.getElementById("notiModal").style.display = 'none';
        };
    </script>
</body>

</html>