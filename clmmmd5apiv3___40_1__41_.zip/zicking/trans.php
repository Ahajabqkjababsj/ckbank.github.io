<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/config/index.php';

$query = "
    (SELECT 'transactions' AS source, nguoichuyen, ketqua, sotien, noidung, da_gui, thoigian 
     FROM transactions 
     WHERE tinhtrang = 'chienthang')
    UNION ALL
    (SELECT 'fakebill' AS source, nguoichuyen, ketqua, sotien, noidung, da_gui, thoigian 
     FROM fakebill 
     WHERE tinhtrang = 'chienthang')
    ORDER BY thoigian DESC
    LIMIT 6
";

$result = $conn->query($query);

if ($result === false) {
    die("Lỗi khi truy vấn cơ sở dữ liệu: " . $conn->error);
}
?>

<div class="row justify-content-md-center box-cl">
    <div class="mt-1">
        <div class="text-center mb-3" style="margin-top:20px;">
            <h4 class="text-uppercase">LỊCH SỬ CHƠI</h4>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-hover text-center">
            <thead>
                <tr role="row" style="background-color: #2b2b30; color: #fff;">
                    <th class="text-center text-white">Số điện thoại</th>
                    <th class="text-center text-white">Tiền đặt</th>
                    <th class="text-center text-white">Nội Dung</th>
                    <th class="text-center text-white">Tình Trạng</th>
                </tr>
            </thead>
            <tbody role="alert" aria-live="polite" aria-relevant="all" class="" id="loaddata">
                <?php 
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?= substr($row['nguoichuyen'], 0, 5) . str_repeat('*', strlen($row['nguoichuyen']) - 5) ?></td>
                            <td><?= number_format($row['sotien'], 0, ',', '.') ?> VNĐ</td>
                            <td><?= $row['noidung'] ?></td>
                            <td>
                                <?php 
                                if ($row['da_gui'] == 0) {
                                    echo '<span class="badge bg-blue text-uppercase">Want</span>';
                                } elseif ($row['da_gui'] == 1) {
                                    echo '<span class="badge bg-success text-uppercase">Send</span>';
                                }
                                ?>
                            </td>
                        </tr>
                    <?php } 
                } else { ?>
                    <tr>
                        <td colspan="5">Không có dữ liệu</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
