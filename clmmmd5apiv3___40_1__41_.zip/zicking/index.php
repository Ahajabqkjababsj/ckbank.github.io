<?php
// Mảng chứa tên món ăn
$foodItems = [
    "Phở bò",
    "Bánh mì thịt",
    "Sushi",
    "Gà rán",
    "Salad trái cây"
];

// Random tên món ăn
$randomFood = $foodItems[array_rand($foodItems)];

// Hàm tạo mã thanh toán ngẫu nhiên
function generatePaymentCode($length = 8) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $code;
}

// Tạo mã thanh toán ngẫu nhiên
$paymentCode = generatePaymentCode();

?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đồ Ăn Ngẫu Nhiên</title>
</head>
<body>
    <h1>Thông Tin Đồ Ăn</h1>
    <p><strong>Món ăn:</strong> <?php echo $randomFood; ?></p>
    <p><strong>Mã thanh toán:</strong> <?php echo $paymentCode; ?></p>
</body>
</html>
