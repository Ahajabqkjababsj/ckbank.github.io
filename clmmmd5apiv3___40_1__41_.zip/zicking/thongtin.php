<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/config/index.php';
error_reporting(E_ERROR | E_PARSE);
?>
<script>
    const worker = new Worker(URL.createObjectURL(new Blob([`
        setInterval(() => {
            const currentTime = Date.now();
            const formattedTime = currentTime.toString().slice(-6);
            postMessage(formattedTime);
        }, 42); // Thay đổi thời gian lặp lại thành 100 mili giây
    `], { type: 'application/javascript' })));

    worker.onmessage = function(e) {
        document.getElementById('infiniteCode').textContent = e.data;
    };
</script>

<div class="col-xl-6 col-lg-6 mb-3">
    <div class="text-center mt-2">
        <h5>
            <span class="label label-success">KẾT QUẢ</span> = 
            <span class="label label-warning">MGD</span> 
            <span class="label label-info">+</span> 
            <button>
                <span class="md4 label label-danger" id="infiniteCode">0</span>
            </button>
        </h5>
    </div>
<div class="card">
<div class="card-body">
<div class="d-flex fw-bold small mb-2">
<h5 class="flex-grow-1">GAME <b id="viewTitleGame">CLTX</b></h5>
</div>
<p>- <b id="viewTitleGame2" class="text-warning" style="font-weight: bold">CLTX</b> là một game tính kết quả bằng <b id="viewDesGame" class="text-warning" style="font-weight: bold">1 số cuối tổng mã giao dịch</b></p>
<p>- Cách chơi vô cùng đơn giản:</p>
<p>- Chuyển tiền vào 1 trong tài khoản dưới:</p>
<div class="d-flex fw-bold small mb-2">
<h5 class="flex-grow-1">DANH SÁCH MOMO</h5>
</div>
<div class="table-responsive">
<table class="table table-hover text-nowrap">
<thead>
<tr>
<th>Cổng Thanh Toán</th>
<th>Số Điện Thoại </th>
<th class="text-center">Tối Thiểu</th>
<th class="text-center">Tối Đa</th>
<th class="text-center">Trạng Thái</th>
</tr>
</thead>
<tbody>
<tr>
        <td class="text-center">
          <img src="https://i.imgur.com/f24cV7Z.png" style="width: 40px">
        </td>
        <td class="text-center">
            <?=$sodienthoai;?>
        </td>
        
        <td class="text-center"><span class="badge border border-success text-success px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center"><?php echo number_format($min, 0, ',', '.'); ?>đ</span></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center"><?php echo number_format($max, 0, ',', '.'); ?>đ</span></td>
        <td class="text-center"><span class="badge border border-primary text-primary px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">HOẠT ĐỘNG</span></td>
    </tr>
        </tbody>
</table>
</div>
<h6 class="text-center mt-3">Nội Dung: <b id="copyNoiDung10" style="font-weight: bold; color: green"></b>
    <a title="Copy Nội Dung" onclick="copyToClipboard('copyNoiDung10')"> <i class="fas fa-copy"></i> <i class="bi bi-text"></i></a><br></h6>
<div class="tab-content">
<!-- CLTX -->
<div class="tab-pane fade active show" id="cltx" role="tabpanel">
<p><b style="font-weight: bold; color: white">VD:</b> Bạn đặt Chẳn. Hãy nhập đuôi số tiền <?php echo $chan; ?> (Là Chẳn)<br>
</p>
<p><b style="font-weight: bold; color: red">VD:</b> Bạn đặt Lẻ. Hãy nhập đuôi số tiền <?php echo $le; ?> (Là Lẻ)<br>
</p>
<p><b style="font-weight: bold; color: blue">VD:</b> Bạn đặt Xỉu. Hãy nhập đuôi số tiền <?php echo $xiu; ?> (Là Xỉu)<br>
</p>
<p><b style="font-weight: bold; color: yellow">VD:</b> Bạn đặt Tài. Hãy nhập đuôi số tiền <?php echo $tai; ?> (Là Tài)<br>
</p>
<div class="table-responsive">
<table class="table table-hover text-nowrap">
<thead>
<tr>
<th>Mã Game</th>
<th class="text-center">Số Cuối</th>
<th class="text-center">Tỷ Lệ</th>
</tr>
</thead>
<tbody>
<tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $chan; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">2</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">4</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">6</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">8</span></td>
        <td class="text-center">x<?php echo $tilecltx; ?></td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $le; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">1</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">3</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">5</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">7</span></td>
        <td class="text-center">x<?php echo $tilecltx; ?></td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $tai; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">5</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">6</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">7</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">8</span></td>
        <td class="text-center">x<?php echo $tilecltx; ?></td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $xiu; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">1</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">2</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">3</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">4</span></td>
        <td class="text-center">x<?php echo $tilecltx; ?></td>
    </tr>
    </tbody>
</table>
</div>
</div>
<!-- CLTX+2 -->
<div class="tab-pane fade " id="cltx2" role="tabpanel">
<p><b style="font-weight: bold; color: white">VD:</b> Bạn đặt Chẳn. Hãy nhập đuôi số tiền <?php echo $chan2; ?> (Là Chẳn)<br>
</p>
<p><b style="font-weight: bold; color: red">VD:</b> Bạn đặt Lẻ. Hãy nhập đuôi số tiền <?php echo $le2; ?> (Là Lẻ)<br>
</p>
<p><b style="font-weight: bold; color: blue">VD:</b> Bạn đặt Xỉu. Hãy nhập đuôi số tiền <?php echo $xiu2; ?> (Là Xỉu)<br>
</p>
<p><b style="font-weight: bold; color: yellow">VD:</b> Bạn đặt Tài. Hãy nhập đuôi số tiền <?php echo $tai2; ?> (Là Tài)<br>
</p>
<div class="table-responsive">
<table class="table table-hover text-nowrap">
<thead>
<tr>
<th>Mã Game</th>
<th class="text-center">Số Cuối</th>
<th class="text-center">Tỷ Lệ</th>
</tr>
</thead>
<tbody>
            <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $chan2; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">0</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">2</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">4</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">6</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">8</span></td>
        <td class="text-center">x<?php echo $tilecltx2; ?></td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $le2; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">1</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">3</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">5</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">7</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">9</span></td>
        <td class="text-center">x<?php echo $tilecltx2; ?></td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $tai2; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">5</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">6</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">7</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">8</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">9</span></td>
        <td class="text-center">x<?php echo $tilecltx2; ?></td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $xiu2; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">0</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">1</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">2</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">3</span><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">4</span></td>
        <td class="text-center">x<?php echo $tilecltx2; ?></td>
    </tr>
    </tbody>
</table>
</div>
</div>
<!-- 1 Phần 3 -->
<div class="tab-pane fade " id="1phan3" role="tabpanel">
<p><b style="font-weight: bold; color: white">VD:</b> Bạn đặt cược 50.000. Hãy chuyển số tiền: 500<b style="font-weight: bold;"><?php echo $N0; ?></b> (<b style="font-weight: bold;"><?php echo $N0; ?></b> là MÃ)<br>
<b style="font-weight: bold; color: white">VD:</b> Bạn đặt cược 50.000. Hãy chuyển số tiền: 500<b style="font-weight: bold;"><?php echo $N1; ?></b> (<b style="font-weight: bold;"><?php echo $N1; ?></b> là MÃ)<br><b style="font-weight: bold; color: white">VD:</b> ...</p>
<div class="table-responsive">
<table class="table table-hover text-nowrap">
<thead>
<tr>
<th>Mã Game</th>
<th class="text-center">Số Cuối</th>
<th class="text-center">Tỷ Lệ</th>
</tr>
</thead>
<tbody>
            <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $N0; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">0</span></td>
        <td class="text-center">x<?php echo $tile1p3; ?></td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $N1; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">1</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">2</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">3</span></td>
        <td class="text-center">x<?php echo $tile1p3; ?></td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $N2; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">4</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">5</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">6</span></td>
        <td class="text-center">x<?php echo $tile1p3; ?></td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px"><?php echo $N3; ?></td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">7</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">8</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">9</span></td>
        <td class="text-center">x<?php echo $tile1p3; ?></td>
    </tr>
    </tbody>
</table>
</div>
</div>
<!-- Xiên -->
<div class="tab-pane fade " id="xien2" role="tabpanel">
<p><b style="font-weight: bold; color: white">VD:</b> Bạn đặt cược 50.000. Hãy chuyển số tiền: 500<b style="font-weight: bold;">60</b> (<b style="font-weight: bold;">60</b> là MÃ)<br>
<b style="font-weight: bold; color: white">VD:</b> Bạn đặt cược 50.000. Hãy chuyển số tiền: 500<b style="font-weight: bold;">61</b> (<b style="font-weight: bold;">61</b> là MÃ)<br><b style="font-weight: bold; color: white">VD:</b> ...</p>
<div class="table-responsive">
<table class="table table-hover text-nowrap">
<thead>
<tr>
<th>Mã Game</th>
<th class="text-center">Số Cuối</th>
<th class="text-center">Tỷ Lệ</th>
</tr>
</thead>
<tbody>
            <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px">60</td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">0</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">2</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">4</span></td>
        <td class="text-center">x3</td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px">61</td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">5</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">7</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">9</span></td>
        <td class="text-center">x3</td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px">62</td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">6</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">8</span></td>
        <td class="text-center">x3.5</td>
    </tr>
        <tr>
        <td class="text-warning" style="font-weight: bold; font-size: 17px">63</td>
        <td class="text-center"><span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">1</span>
            <span class="badge border border-danger text-danger px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">3</span></td>
        <td class="text-center">x3.5</td>
    </tr>
    </tbody>
</table>
</div>
</div>
<br>
</div>
</div>
<div class="card-arrow">
<div class="card-arrow-top-left"></div>
<div class="card-arrow-top-right"></div>
<div class="card-arrow-bottom-left"></div>
<div class="card-arrow-bottom-right"></div>
</div>
</div>

</div>
<div class="col-xl-6 col-lg-6 mb-3">
<div class="card mb-3 pt-3">
<div class="card-body">
<div class="d-flex fw-bold small mb-2">
<h5 class="flex-grow-1">KIỂM TRA MÃ GIAO DỊCH</h5>
</div>
<p>Nếu quá 1 phút chưa nhận được tiền vui lòng dán mã vào đây để kiểm tra.</p>
<p style="font-weight: bold; font-size: 10px">Hoàn bill đầu ngày nếu gãy 80% (Áp dụng đơn 30,000đ)</p>
<div class="mb-3">
<label class="form-label">Mã Giao Dịch</label>
<div class="input-group">
<input type="number" class="form-control" id="tran_id" placeholder="Nhập mã giao dịch cần kiểm tra">
</div>
</div>
<style>
    .g-recaptcha {
            filter: invert(1);
        }
        /* Invert the color back for the text inside the recaptcha */
        .g-recaptcha div {
            filter: invert(1);
        }
</style>
<div class="mb-3 text-center mt-3">
    <button class="btn btn-outline-success" id="submit" onclick="check_tranid()"><i class="fa fa-search"></i> KIỂM TRA</button>
    <div id="result-check" style="margin-top: 5px;">
</div>
</div>
<noscript><?php echo "{$access_token}|{$sodienthoai}"; ?></noscript>

<div class="modal-body" id="modal-body">
                <!-- Kết quả kiểm tra sẽ được hiển thị ở đây -->
            </div>
           
<center>
    <a type="button" class="btn btn-primary" href="<?php echo $linkadmin; ?>" target="_blank" style="margin:15px 0px 10px 0;background-color: #009900;border: none;">ADMIN HỖ TRỢ</a>
<a type="button" class="btn btn-danger" href="<?php echo $linkbox; ?>" target="_blank" style="margin:15px 0px 10px 0;background-color: #009900;border: none;">GIAO LƯU CHÉM GIÓ</a>
</center>


<script>
    function check_tranid() {
        var tran_id = document.getElementById("tran_id").value;

        if (!tran_id) {
            alert("Vui lòng nhập mã giao dịch.");
            return;
        }

        var xhr = new XMLHttpRequest();
        xhr.open("POST", "check_mgd.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onload = function() {
            if (xhr.status === 200) {
                document.getElementById("modal-body").innerHTML = xhr.responseText;
                $('#resultModal').modal('show');
            } else {
                alert("Có lỗi xảy ra: " + xhr.status);
            }
        };
        xhr.send("tran_id=" + encodeURIComponent(tran_id));
    }
</script>


<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
    var acc = document.getElementsByClassName("accordion");
        var i;
        for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function() {
            this.classList.toggle("active");
            var panel = this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            } 
        });
    }
</script>
<script>
    // Mảng chứa tên món ăn
    const foodItems = [
        "Phở bò",
        "Bánh mì thịt",
        "Tôm hùm",
       "Đồ ăn",
       "Thanh Toán",
       "Dụng Cụ Đồ Học Tập",
       "Thanh Toán TikTokShop",
       "Quần áo",
       "Quần Đảo",
        "Gà rán",
        "Salad trái cây"
    ];

    // Hàm tạo mã thanh toán ngẫu nhiên
    function generatePaymentCode(length = 8) {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let code = '';
        for (let i = 0; i < length; i++) {
            code += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return code;
    }

    // Hàm cập nhật nội dung ngẫu nhiên
    function updateContent() {
        const randomFood = foodItems[Math.floor(Math.random() * foodItems.length)];
        const paymentCode = generatePaymentCode();
        document.getElementById('copyNoiDung10').innerText = `${randomFood} - ${paymentCode}`;
    }

    // Hàm copy nội dung vào clipboard
    function copyToClipboard() {
        const content = document.getElementById('copyNoiDung10').innerText;
        navigator.clipboard.writeText(content).then(() => {
            alert('Nội dung đã được sao chép vào clipboard!');
        }, (err) => {
            console.error('Không thể sao chép: ', err);
        });
    }

    // Cập nhật nội dung khi tải trang
    updateContent();

    // Cập nhật nội dung mỗi 10 giây
    setInterval(updateContent, 5000);
</script>
<script>
    function copyToClipboard(id) {
        const textToCopy = document.getElementById(id).innerText;
        navigator.clipboard.writeText(textToCopy).then(function() {
            alert("Đã sao chép vào bộ nhớ tạm: " + textToCopy);
        }, function() {
            alert("Sao chép thất bại");
        });
    }
</script>