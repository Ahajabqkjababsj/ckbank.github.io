-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th10 21, 2024 lúc 11:42 PM
-- Phiên bản máy phục vụ: 10.11.9-MariaDB
-- Phiên bản PHP: 8.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `inaptheclick_demo`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chuyentien_thucong`
--

CREATE TABLE `chuyentien_thucong` (
  `id` int(11) NOT NULL,
  `phoneto` varchar(15) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `thoigian` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `fakebill`
--

CREATE TABLE `fakebill` (
  `id` int(11) NOT NULL,
  `nguoichuyen` varchar(255) NOT NULL,
  `tennguoichuyen` varchar(255) NOT NULL,
  `magiaodich` varchar(255) NOT NULL,
  `mard` varchar(4) NOT NULL,
  `ketqua` varchar(259) NOT NULL,
  `sotien` varchar(5555) NOT NULL,
  `noidung` text DEFAULT NULL,
  `tinhtrang` varchar(50) NOT NULL,
  `thoigian` datetime NOT NULL,
  `da_gui` tinyint(1) DEFAULT 0,
  `trathuong` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `fakebill`
--

INSERT INTO `fakebill` (`id`, `nguoichuyen`, `tennguoichuyen`, `magiaodich`, `mard`, `ketqua`, `sotien`, `noidung`, `tinhtrang`, `thoigian`, `da_gui`, `trathuong`) VALUES
(1, '0371375645', 'Người dùng zUnJ7', 'hizfIv3a4x', '9xHr', 'hizfIv3a4x9xHr', '30000', 'x', 'chienthang', '2024-10-21 20:26:02', 1, '72000'),
(2, '0338660270', 'Người dùng KNuPk', 'znDdlUR7SL', 'IkWh', 'znDdlUR7SLIkWh', '19003', '', 'chienthang', '2024-10-22 06:42:03', 1, '45607.2');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rewards`
--

CREATE TABLE `rewards` (
  `id` int(11) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `reward_amount` int(11) NOT NULL,
  `date_rewarded` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `nguoichuyen` varchar(255) NOT NULL,
  `tennguoichuyen` varchar(255) NOT NULL,
  `magiaodich` varchar(255) NOT NULL,
  `mard` varchar(4) NOT NULL,
  `ketqua` varchar(259) NOT NULL,
  `sotien` varchar(5555) NOT NULL,
  `noidung` text DEFAULT NULL,
  `tinhtrang` varchar(50) NOT NULL,
  `thoigian` datetime NOT NULL,
  `da_gui` tinyint(1) DEFAULT 0,
  `trathuong` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `transactions`
--

INSERT INTO `transactions` (`id`, `nguoichuyen`, `tennguoichuyen`, `magiaodich`, `mard`, `ketqua`, `sotien`, `noidung`, `tinhtrang`, `thoigian`, `da_gui`, `trathuong`) VALUES
(341, '0358163713', 'Nguyễn Phi Long', '69570846498', '6370', '695084649897753', '10003', '', 'chienthang', '2024-10-21 19:54:17', 0, NULL),
(342, '0358163713', 'Nguyễn Phi Long', '69570924732', '1663', '695709473247504', '15004', '', 'chienthang', '2024-10-21 19:53:31', 0, NULL),
(343, '0358163713', 'Nguyễn Phi Long', '69570922428', '7527', '695709224287527', '10002', '', 'chienthang', '2024-10-21 19:52:11', 0, NULL),
(344, '0358163713', 'Nguyễn Phi Long', '69570656907', '2996', '695706569072996', '30002', '', 'chienthang', '2024-10-21 19:50:45', 0, NULL),
(345, '0358163713', 'Nguyễn Phi Long', '69570567756', '6523', '695705677566523', '20001', '', 'chienthang', '2024-10-21 19:49:29', 0, NULL),
(346, '0358163713', 'Nguyễn Phi Long', '69570563967', '4995', '69705639673921', '30002', '', 'chienthang', '2024-10-21 19:47:35', 0, NULL),
(347, '0358163713', 'Nguyễn Tài Cường', '69569976710', '1189', '695699767101189', '50008', '🍛 Tiền ăn uống', 'chienthang', '2024-10-21 19:32:47', 0, NULL),
(348, '0358163713', 'Nguyễn Tài Cường', '69569896263', '4958', '695698966397273', '100002', '🍛 Tiền ăn uống', 'chienthang', '2024-10-21 19:31:03', 0, NULL),
(349, '0358163713', 'Nguyễn Tài Cường', '69569818243', '6740', '695981824368411', '20001', '🎦 Tiền xem phim', 'chienthang', '2024-10-21 19:30:02', 0, NULL),
(350, '0358163713', 'Nguyễn Tài Cường', '69569737037', '0694', '695973703726773', '50003', '', 'chienthang', '2024-10-21 19:29:00', 0, NULL),
(351, '0358163713', 'Nguyễn Tài Cường', '69589974922', '1335', '69589979229813', '20005', '', 'chienthang', '2024-10-22 06:07:48', 0, NULL),
(352, '0358163713', 'Nguyễn Tài Cường', '69589978231', '6826', '69589985057', '77306', '', 'chienthang', '2024-10-22 06:09:03', 0, NULL),
(353, '0358163713', 'Nguyễn Tài Cường', '69590065187', '9757', '69590074944', '300003', '🍛 Tiền ăn uống', 'chienthang', '2024-10-22 06:12:01', 0, NULL),
(354, '0358163713', 'Nguyễn Tài Cường', '69590067802', '8662', '69590678045', '100002', '📦 Trả tiền hàng', 'chienthang', '2024-10-22 06:13:03', 0, NULL);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `chuyentien_thucong`
--
ALTER TABLE `chuyentien_thucong`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `fakebill`
--
ALTER TABLE `fakebill`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `rewards`
--
ALTER TABLE `rewards`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `chuyentien_thucong`
--
ALTER TABLE `chuyentien_thucong`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `fakebill`
--
ALTER TABLE `fakebill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=610;

--
-- AUTO_INCREMENT cho bảng `rewards`
--
ALTER TABLE `rewards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=355;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
